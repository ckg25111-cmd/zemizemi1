// 共通の関数
const params = new URLSearchParams(location.search);
const $ = id => document.getElementById(id);
const catName = id => (CATEGORIES.find(c => c.id === id) || {}).name || '';
const peopleLabel = n => (n === 3 ? '3人以上' : n + '人');
const peopleText = s => s.people.map(peopleLabel).join('・');
const kidsLabel = s => (s.kids ? '<span class="label">子連れOK</span>' : '');

// 英字と日本語の見出し
const secTitle = (en, ja) => `<h2 class="sec-title"><span class="en">${en}</span><span class="ja">${ja}</span></h2>`;

// 画像がない間はグレーの枠のままになる
function photo(src, alt) {
  return `<div class="ph"><img src="${src}" alt="${alt}" loading="lazy" onerror="this.remove()"></div>`;
}
// バナーの箱（PC用とSP用を切り替え）
function bannerPic(pc, sp, label) {
  return `<span class="dummy">${label}</span>
    <picture><source media="(min-width:768px)" srcset="${pc}"><img src="${sp}" alt="${label}" onerror="this.remove()"></picture>`;
}

// スポットカード
function card(s) {
  return `<a class="card" href="spot.html?id=${s.id}">
    ${photo(s.image, s.name)}
    <div class="card-body">
      <p class="small">${catName(s.category)}　${s.area}</p>
      <h3>${s.name}</h3>
      <p class="small">${peopleText(s)}${kidsLabel(s)}</p>
      <p>${s.summary}</p>
    </div></a>`;
}
function renderCards(el, list) {
  el.innerHTML = list.length ? list.map(card).join('') : '<p>該当するスポットはまだありません。</p>';
}

// ヘッダー
const navItems = CATEGORIES.map(c => `<li><a href="category.html?cat=${c.id}">${c.name}</a></li>`).join('');
$('header').innerHTML = `<header class="header"><div class="wrap">
  <a class="logo" href="index.html">${SITE.logo ? `<img src="${SITE.logo}" alt="${SITE.name}">` : SITE.name}</a>
  <button class="menu-btn" id="menu-btn" aria-label="メニュー"><span></span><span></span><span></span></button>
  <nav class="nav" id="nav"><ul><li><a href="index.html">ホーム</a></li>${navItems}<li><a href="season.html">季節</a></li></ul></nav>
</div></header>`;

// スマホメニュー
$('menu-btn').addEventListener('click', () => $('nav').classList.toggle('open'));

// フッター
$('footer').innerHTML = `<footer class="footer"><div class="wrap">
  <p class="logo">${SITE.name}</p>
  <p class="small">福岡のお出かけスポット紹介サイト（卒業制作）</p>
</div></footer>`;

// トップページ
if ($('category-banners')) {
  // カテゴリーバナー（images/banners/category-ID.jpg）
  $('category-banners').innerHTML = CATEGORIES.map(c =>
    `<a class="banner" href="category.html?cat=${c.id}"><div class="ph">
      <span class="dummy">${c.name}バナー</span>
      <img src="images/banners/category-${c.id}.jpg" alt="${c.name}" onerror="this.remove()"></div></a>`).join('');
  // おすすめスポット
  renderCards($('recommend'), SPOTS.filter(s => s.recommend).slice(0, 3));
  // 特集バナー
  $('features').innerHTML = FEATURES.slice(0, 3).map(f =>
    `<a class="banner" href="feature.html?id=${f.id}"><div class="ph">
      ${bannerPic(`images/banners/feature-${f.id}-pc.jpg`, `images/banners/feature-${f.id}-sp.jpg`, f.title + 'バナー')}
    </div></a>`).join('');
  // 新着スポット（最後の4件）
  renderCards($('new-spots'), SPOTS.slice(-4).reverse());
}

// カテゴリー一覧ページ
if ($('spot-list')) {
  const cat = CATEGORIES.find(c => c.id === params.get('cat')) || CATEGORIES[0];
  document.title = cat.name + '｜' + SITE.name;
  $('cat-title').innerHTML = `<span class="en">${cat.en || ''}</span>${cat.name}`;
  $('cat-desc').textContent = cat.desc;
  const inCat = SPOTS.filter(s => s.category === cat.id);
  renderCards($('spot-list'), inCat);

  // 人数切り替え
  document.querySelectorAll('#tabs button').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#tabs button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const v = btn.dataset.people;
      renderCards($('spot-list'), v === 'all' ? inCat : inCat.filter(s => s.people.includes(Number(v))));
    });
  });
  // 他のカテゴリー
  $('other-cats').innerHTML = CATEGORIES.filter(c => c.id !== cat.id)
    .map(c => `<a href="category.html?cat=${c.id}">${c.name}</a>`).join('');
}

// 季節ページ（?s=summer のように季節を指定できます）
if ($('season-list')) {
  const tabs = $('season-tabs');
  const first = SEASONS.find(x => x.id === params.get('s')) || SEASONS[0];
  // タブは spots.js の SEASONS から作る
  tabs.style.setProperty('--cols', SEASONS.length);
  tabs.innerHTML = SEASONS.map(x => `<button data-season="${x.id}" aria-pressed="false">${x.name}</button>`).join('');
  const show = season => {
    document.title = season.name + 'のおでかけ｜' + SITE.name;
    $('season-desc').textContent = season.desc;
    tabs.querySelectorAll('button').forEach(b => {
      const on = b.dataset.season === season.id;
      b.classList.toggle('active', on);
      b.setAttribute('aria-pressed', on);
    });
    renderCards($('season-list'), SPOTS.filter(x => x.seasons && x.seasons.includes(season.id)));
  };
  tabs.querySelectorAll('button').forEach(b => {
    b.addEventListener('click', () => show(SEASONS.find(x => x.id === b.dataset.season)));
  });
  show(first);
}

// スポット詳細ページ
if ($('spot')) {
  const s = SPOTS.find(x => x.id === params.get('id')) || SPOTS[0];
  document.title = s.name + '｜' + SITE.name;
  const info = [['所在地', s.address], ['おすすめの季節', s.seasonText], ['料金の目安', s.price], ['営業時間', s.hours],
    ['休業日', s.closed], ['アクセス', s.access],
    ['公式サイト', s.url ? `<a href="${s.url}" target="_blank" rel="noopener">${s.url}</a>` : '']]
    .filter(r => r[1]).map(r => `<dt>${r[0]}</dt><dd>${r[1]}</dd>`).join('');
  const related = SPOTS.filter(x => x.category === s.category && x.id !== s.id).slice(0, 3);
  $('spot').innerHTML = `
    <p class="crumb small"><a href="index.html">ホーム</a> &gt; <a href="category.html?cat=${s.category}">${catName(s.category)}</a> &gt; ${s.name}</p>
    <div class="detail-main">${photo(s.image, s.name)}</div>
    <h1 class="spot-title">${s.name}</h1>
    <p class="small">${catName(s.category)}　${s.area}　${peopleText(s)}${kidsLabel(s)}</p>
    ${s.catch ? `<p class="catch">${s.catch}</p>` : ''}
    <p class="lead">${s.summary}</p>
    ${s.points ? `${secTitle('Point', 'おすすめポイント')}${s.points.map(p => `<p>${p}</p>`).join('')}` : ''}
    ${s.gallery && s.gallery.length ? `${secTitle('Photos', '写真')}<div class="gallery">${s.gallery.map(g => photo(g, s.name)).join('')}</div>` : ''}
    ${s.notes && s.notes.length ? `${secTitle('Note', '行く前に')}${s.notes.map(n => `<p>${n}</p>`).join('')}` : ''}
    ${secTitle('Info', '基本情報')}<dl class="info">${info}</dl>
    ${related.length ? `${secTitle('Related', '関連スポット')}<div class="card-grid">${related.map(card).join('')}</div>` : ''}`;
}

// 特集ページ
if ($('feature')) {
  const f = FEATURES.find(x => x.id === params.get('id')) || FEATURES[0];
  document.title = f.title + '｜' + SITE.name;
  $('feature-title').textContent = f.title;
  $('feature-intro').textContent = f.intro;
  renderCards($('feature-list'), f.spots.map(id => SPOTS.find(s => s.id === id)).filter(Boolean));
}

// オープニング（最初の1回だけ）
const opening = $('opening');
if (opening) {
  const root = document.documentElement;
  const done = () => { opening.remove(); root.classList.remove('opening-on'); };
  if (root.classList.contains('opening-on')) {
    sessionStorage.setItem('opened', '1');
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) done();
    else { setTimeout(() => opening.classList.add('out'), 2200); setTimeout(done, 3200); }
  } else opening.remove();
}
