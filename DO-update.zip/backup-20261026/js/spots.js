// サイト名とロゴ（ここを変えると全ページに反映）
// ロゴ画像を使う場合は logo に 'images/logo.png' のように入れる
const SITE = { name: 'ふくおかおでかけ帳', logo: '' };

// カテゴリー（追加するときは1つ足すだけ）
const CATEGORIES = [
  { id: 'play', en: 'Play',    name: '遊び',       desc: '友達や家族と体を動かして楽しめる場所です。' },
  { id: 'nature', en: 'Nature', name: '自然・絶景', desc: '山、海、滝、花畑など、景色のきれいな場所です。' },
  { id: 'indoor', en: 'Indoor',  name: '室内',       desc: '天気に関係なく楽しめる施設です。' },
  { id: 'gourmet', en: 'Gourmet', name: 'グルメ',     desc: '食べることが目的のお出かけ先です。' },
  { id: 'relax', en: 'Relax',   name: '癒し',       desc: 'ゆっくり過ごしたいときの場所です。' }
];

// 季節（季節ページのタブになります。秋の次に冬を足すときは1行足すだけ）
// スポット側で seasons: ['summer'] のように id を指定すると、そのタブに表示されます
const SEASONS = [
  { id: 'summer', en: 'Summer', name: '夏', desc: '暑い日に行きたい、涼しい場所や夏らしい景色です。' },
  { id: 'autumn', en: 'Autumn', name: '秋', desc: '紅葉など、秋ならではの景色を楽しめる場所です。' }
];

// 追加で使える項目（なければ詳細ページに出ません）
// catch=キャッチコピー / address=所在地 / closed=休業日 / seasonText=おすすめの季節
// seasons=季節ページに出す季節のid / url=公式サイト / notes=行く前の注意

// 特集（トップページに最初の3件が出ます）
// バナー画像は images/banners/feature-ID-pc.jpg と feature-ID-sp.jpg
const FEATURES = [
  { id: 'rainy',  title: '雨の日に楽しめるスポット', intro: '天気が悪い日でも出かけやすい場所を集めました。', spots: ['indoor-1', 'indoor-2', 'relax-1'] },
  { id: 'budget', title: '予算3,000円以内のお出かけ', intro: '料金を抑えて楽しめる場所です。', spots: ['nature-1', 'nature-2', 'gourmet-1', 'relax-2'] },
  { id: 'family', title: '子どもと一緒に行ける休日スポット', intro: '子連れでも行きやすい場所を紹介します。', spots: ['play-1', 'nature-1', 'indoor-1'] }
];

// スポット（データのかたまりを1つ足すだけで追加できます）
// people は 1=1人 2=2人 3=3人以上 / kids は子連れOKなら true
// 新着スポットは配列の最後の4件が表示されます
const SPOTS = [
  {
    id: 'play-1', name: 'ボウリング場（仮）', category: 'play', area: '天神',
    people: [2, 3], kids: true, recommend: true,
    image: 'images/spots/play-1.jpg',
    summary: '友達同士でも家族でも遊びやすい、定番のスポットです。',
    price: '1ゲーム 600円前後', hours: '10:00〜24:00', access: '地下鉄天神駅から徒歩5分',
    gallery: ['images/spots/play-1-a.jpg', 'images/spots/play-1-b.jpg', 'images/spots/play-1-c.jpg'],
    points: ['靴の貸し出しがあり、手ぶらで行けます。', '平日は比較的すいています。']
  },
  {
    id: 'play-2', name: 'ゲームセンター（仮）', category: 'play', area: '博多',
    people: [1, 2, 3], kids: false,
    image: 'images/spots/play-2.jpg',
    summary: 'ひとりでも、友達とでも気軽に立ち寄れます。',
    price: '1,000円〜', hours: '10:00〜23:00', access: 'JR博多駅から徒歩8分',
    gallery: [], points: ['プリクラやクレーンゲームが充実しています。']
  },
  {
    id: 'nature-1', name: '海辺の公園（仮）', category: 'nature', area: '百道',
    people: [1, 2, 3], kids: true, recommend: true,
    image: 'images/spots/nature-1.jpg',
    summary: '海を眺めながら散歩できる広い公園です。',
    price: '無料', hours: '24時間', access: '西鉄バス 百道浜から徒歩3分',
    gallery: ['images/spots/nature-1-a.jpg', 'images/spots/nature-1-b.jpg'],
    points: ['夕方は景色がきれいです。', '駐車場が近くにあります。']
  },
  {
    id: 'nature-2', name: '山の展望台（仮）', category: 'nature', area: '糸島',
    people: [1, 2], kids: false,
    image: 'images/spots/nature-2.jpg',
    summary: '車で行ける展望台。景色を見に行くのにおすすめです。',
    price: '無料', hours: '終日', access: '車で福岡市内から約60分',
    gallery: [], points: ['天気のよい日が向いています。']
  },
  {
    id: 'indoor-1', name: '水族館（仮）', category: 'indoor', area: '東区',
    people: [2, 3], kids: true, recommend: true,
    image: 'images/spots/indoor-1.jpg',
    summary: '雨の日でも楽しめる、大きな水族館です。',
    price: '大人 2,500円', hours: '9:30〜17:30', access: '電車とバスで博多駅から約40分',
    gallery: ['images/spots/indoor-1-a.jpg', 'images/spots/indoor-1-b.jpg', 'images/spots/indoor-1-c.jpg'],
    points: ['ショーの時間は事前に確認しておくと安心です。']
  },
  {
    id: 'indoor-2', name: '美術館（仮）', category: 'indoor', area: '大濠公園',
    people: [1, 2], kids: false,
    image: 'images/spots/indoor-2.jpg',
    summary: '静かに過ごしたいときに向いています。',
    price: '1,200円', hours: '10:00〜17:00', access: '地下鉄大濠公園駅から徒歩5分',
    gallery: [], points: ['公園の散歩とあわせて行けます。']
  },
  {
    id: 'gourmet-1', name: 'もつ鍋のお店（仮）', category: 'gourmet', area: '中洲',
    people: [2, 3], kids: false, recommend: true,
    image: 'images/spots/gourmet-1.jpg',
    summary: '福岡らしいものを食べたい日におすすめです。',
    price: '1人 2,500円前後', hours: '17:00〜23:00', access: '地下鉄中洲川端駅から徒歩3分',
    gallery: [], points: ['予約しておくとスムーズです。']
  },
  {
    id: 'gourmet-2', name: 'カフェ（仮）', category: 'gourmet', area: '大名',
    people: [1, 2], kids: true,
    image: 'images/spots/gourmet-2.jpg',
    summary: '落ち着いた雰囲気で、休憩にも使いやすいお店です。',
    price: '1人 1,000円前後', hours: '10:00〜19:00', access: '地下鉄赤坂駅から徒歩7分',
    gallery: [], points: ['ランチの時間帯は混みあいます。']
  },
  {
    id: 'relax-1', name: '温泉施設（仮）', category: 'relax', area: '博多',
    people: [1, 2, 3], kids: true, recommend: true,
    image: 'images/spots/relax-1.jpg',
    summary: '雨の日でも使いやすい、日帰りの温泉です。',
    price: '大人 1,500円', hours: '10:00〜23:00', access: '博多駅から車で10分',
    gallery: [], points: ['タオルのレンタルがあります。']
  },
  {
    id: 'relax-2', name: '日本庭園（仮）', category: 'relax', area: '中央区',
    people: [1, 2], kids: false,
    image: 'images/spots/relax-2.jpg',
    summary: '街なかで静かに過ごせる庭園です。',
    price: '300円', hours: '9:00〜17:00', access: '地下鉄大濠公園駅から徒歩10分',
    gallery: [], points: ['朝の時間帯は人が少なめです。']
  },
  // ここから追加分。料金や時間は変わることがあるので、行く前に公式サイトで確認してください
  {
    id: 'indoor-3', name: '北九州市立いのちのたび博物館', category: 'indoor', area: '北九州市八幡東区',
    people: [2, 3], kids: true,
    image: 'images/spots/indoor-3.jpg',
    catch: '恐竜の骨に会いに行く、雨の日のおでかけ。',
    summary: '大きな恐竜の骨格標本が並ぶ、自然史と歴史の博物館です。',
    address: '福岡県北九州市八幡東区東田2-4-1',
    price: '常設展 大人600円 / 高校生以上の学生360円 / 小・中学生240円 / 小学生未満は無料',
    hours: '9:00〜17:00（入館は16:30まで）',
    closed: '年末年始、害虫駆除期間（年によって日程が変わります）',
    seasonText: '一年中（雨の日や暑い日にも）',
    access: 'JRスペースワールド駅から徒歩約5分。北九州都市高速の東田出入口から車で約2分',
    url: 'https://www.kmnh.jp/',
    gallery: [],
    points: [
      '大迫力の恐竜の骨格標本を見られます。',
      '自然の歴史と人の歴史を、見ながら学べます。',
      '屋内なので、雨の日や暑い日でも楽しめます。',
      'デートや友達とのおでかけにも向いています。'
    ],
    notes: ['駐車場は東田博物館ゾーンの共同駐車場です。普通車は30分100円、4時間以上は一律800円です。']
  },
  {
    id: 'nature-3', name: '草千里ヶ浜', category: 'nature', area: '熊本県阿蘇市',
    people: [1, 2, 3], kids: true,
    image: 'images/spots/nature-3.jpg',
    catch: '空まで続くような、阿蘇の大草原。',
    summary: '阿蘇を代表する、広くて開放感のある草原です。',
    address: '熊本県阿蘇市草千里ケ浜',
    price: '散策は無料（駐車場は有料。普通車500円という情報あり。要確認）',
    hours: '要確認', closed: '要確認',
    seasonText: '春から秋（春は新緑、夏は青い草原、秋はススキ、冬は雪景色）',
    access: '車で熊本市内から約1時間30分。JR阿蘇駅からバスで草千里（阿蘇火山博物館前）下車',
    url: '',
    gallery: [],
    points: [
      '見渡すかぎりの草原で、開放感があります。',
      '季節によって景色が変わります。',
      'ドライブや写真撮影におすすめです。'
    ],
    notes: [
      '標高が高く風が強い日があります。春や秋は羽織るものがあると安心です。',
      '火山ガスなどで散策が制限されることがあります。行く前に最新情報を確認してください。',
      '放牧されている動物には近づきすぎないようにしてください。'
    ]
  },
  {
    id: 'nature-4', name: '菊池渓谷', category: 'nature', area: '熊本県菊池市',
    people: [1, 2, 3], kids: false,
    image: 'images/spots/nature-4.jpg',
    catch: '夏の暑さを忘れる、天然のクーラー。',
    summary: '夏に行けば涼める！清らかな流れと緑の中を歩ける渓谷です。',
    address: '熊本県菊池市原5026（管理事務所）',
    price: '高校生以上 1人500円',
    hours: '4〜11月は8:30〜17:00',
    closed: '定休日の記載なし（大雨警報時は閉鎖されることがあります）',
    seasonText: '夏（避暑）',
    seasons: ['summer'],
    access: '福岡市から九州自動車道で車で約2時間10分。駐車場は無料です',
    url: 'https://kikuchikeikoku.com/',
    gallery: [],
    points: [
      '夏に行けば涼める、避暑におすすめのスポットです。',
      '清らかな渓流と豊かな緑の中を散策できます。',
      '涼しさを感じながら、ゆっくり自然を楽しめます。'
    ],
    notes: [
      '足場がすべりやすい場所があります。歩きやすい靴で行ってください。',
      '遊泳は禁止です。',
      '入谷できない日があります。行く前に公式サイトのお知らせを確認してください。'
    ]
  },
  {
    id: 'nature-5', name: '千仏鍾乳洞', category: 'nature', area: '北九州市小倉南区（平尾台）',
    people: [1, 2, 3], kids: false,
    image: 'images/spots/nature-5.jpg',
    catch: '夏こそ行きたい、涼しく神秘的な地下世界。',
    summary: '夏は涼しくて神秘的な絶景。平尾台にある探検気分の鍾乳洞です。',
    address: '福岡県北九州市小倉南区平尾台3-2-1',
    price: '入洞料 大人1,100円 / 中学生600円 / 小学生500円 / 4歳以上200円（現金のみ）',
    hours: '平日9:00〜17:00、土日祝9:00〜18:00（秋冬は日没まで）。入洞受付は終了30分前まで',
    closed: '要確認',
    seasonText: '夏（洞内は一年中約16度）',
    seasons: ['summer'],
    access: '九州自動車道の小倉南ICから車で約20分。駐車場は無料（100台）',
    url: 'http://www.senbutsu-cave.com/',
    gallery: [],
    points: [
      '洞内は一年を通して約16度。夏は涼しく過ごせます。',
      '神秘的な鍾乳石や洞内の景色を見られます。',
      '非日常感のある、探検気分のスポットです。'
    ],
    notes: [
      '洞内では地下水の中を歩きます。深いところで大人の膝下ほどになることがあります。',
      '足元がぬれるため、入口でサンダルを借りる方法があります。',
      '洞内は涼しいので、夏でも羽織るものがあると安心です。',
      '往復で約40分です。夏の土日や8月中旬は混みあうことがあります。'
    ]
  },
  {
    id: 'nature-6', name: '柳川ひまわり園', category: 'nature', area: '福岡県柳川市',
    people: [2, 3], kids: true,
    image: 'images/spots/nature-6.jpg',
    catch: '夏の思い出は、一面のひまわりと。',
    summary: '一面に広がるひまわり畑。写真映えする、夏だけのスポットです。',
    address: '福岡県柳川市橋本町付近',
    price: '要確認（年によって異なります）', hours: '要確認（年によって異なります）',
    closed: '要確認',
    seasonText: '夏（開園する期間は年によって変わります）',
    seasons: ['summer'],
    access: '九州自動車道のみやま柳川ICから車で約30分',
    url: '',
    gallery: [],
    points: [
      '見渡すかぎり、ひまわり畑が広がります。',
      '夏らしいあざやかな景色を楽しめます。',
      '夏のおでかけやデートにおすすめです。'
    ],
    notes: [
      '開園期間は年によって変わります。行く前に最新の情報を確認してください。',
      '駐車場が有料の年があります。'
    ]
  },
  {
    id: 'nature-7', name: '呑山観音寺', category: 'nature', area: '福岡県糟屋郡篠栗町',
    people: [1, 2, 3], kids: false,
    image: 'images/spots/nature-7.jpg',
    catch: '秋色に染まる、福岡屈指の紅葉スポット。',
    summary: '福岡県内でも知られる紅葉の名所。秋は境内がモミジで染まります。',
    address: '福岡県糟屋郡篠栗町萩尾227-4',
    price: '要確認（紅葉まつりの特別拝観は一般500円、中学生以下は無料という情報あり）',
    hours: '午前6時〜午後5時',
    closed: '要確認',
    seasonText: '秋（紅葉）',
    seasons: ['autumn'],
    access: 'JR篠栗駅から車で約15分。福岡ICから車で約20分',
    url: 'https://www.nomiyamakannonji.com/',
    gallery: [],
    points: [
      '福岡県内でも知られる、紅葉の名所です。',
      '秋になると、境内がモミジで赤く染まります。',
      '秋らしい景色や写真撮影を楽しめます。',
      '紅葉まつりの時期には、キッチンカーなどが出店する日があります。'
    ],
    notes: [
      '出店は紅葉まつりの期間に日替わりで出る形で、いつもあるわけではありません。年によって変わるので、公式サイトで確認してください。',
      '交通規制や駐車場の情報は、公式サイトで確認してください。'
    ]
  }
];

// 確認待ち: 太宰府の「宝満寺」は正式名称が確認できていないため、まだ追加していません
// 名称と公式情報が確認できたら、上のSPOTSに seasons: ['autumn'] で追加してください
