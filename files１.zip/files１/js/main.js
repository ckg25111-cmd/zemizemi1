// 共通
const params = new URLSearchParams(location.search);

const $ = id => document.getElementById(id);

const catName = id =>
  (CATEGORIES.find(c => c.id === id) || {}).name || '';

const peopleLabel = n =>
  n === 3 ? '3人以上' : `${n}人`;

const peopleText = spot =>
  spot.people.map(peopleLabel).join('・');

const kidsLabel = spot =>
  spot.kids ? '<span class="label">子連れOK</span>' : '';


// 英字＋日本語見出し
const secTitle = (en, ja) => `
  <h2 class="sec-title">
    <span class="en">${en}</span>
    <span class="ja">${ja}</span>
  </h2>
`;


// 画像
function photo(src, alt) {
  return `
    <div class="ph">
      <img
        src="${src}"
        alt="${alt}"
        loading="lazy"
        onerror="this.remove()"
      >
    </div>
  `;
}


// PC / SPバナー
function bannerPic(pc, sp, label) {
  return `
    <span class="dummy">${label}</span>
    <picture>
      <source media="(min-width: 768px)" srcset="${pc}">
      <img
        src="${sp}"
        alt="${label}"
        onerror="this.remove()"
      >
    </picture>
  `;
}


// スポットカード
function card(spot) {
  return `
    <a class="card" href="spot.html?id=${spot.id}">

      ${photo(spot.image, spot.name)}

      <div class="card-body">

        <p class="small">
          ${catName(spot.category)}　${spot.area}
        </p>

        <h3>${spot.name}</h3>

        <p class="small">
          ${peopleText(spot)}
          ${kidsLabel(spot)}
        </p>

        <p>${spot.summary}</p>

      </div>
    </a>
  `;
}


// カード一覧
function renderCards(element, list) {

  if (!element) return;

  element.innerHTML = list.length
    ? list.map(card).join('')
    : '<p>該当するスポットはまだありません。</p>';
}


// ヘッダー
const header = $('header');

if (header) {

  const navItems = CATEGORIES.map(category => `
    <li>
      <a href="category.html?cat=${category.id}">
        ${category.name}
      </a>
    </li>
  `).join('');

  header.innerHTML = `
    <header class="header">
      <div class="wrap">

        <a class="logo" href="index.html">
          ${
            SITE.logo
              ? `<img src="${SITE.logo}" alt="${SITE.name}">`
              : SITE.name
          }
        </a>

        <button
          class="menu-btn"
          id="menu-btn"
          aria-label="メニュー"
          aria-expanded="false"
        >
          <span></span>
          <span></span>
          <span></span>
        </button>

        <nav class="nav" id="nav">
          <ul>
            <li><a href="index.html">ホーム</a></li>
            ${navItems}
          </ul>
        </nav>

      </div>
    </header>
  `;


  // スマホメニュー
  const menuButton = $('menu-btn');
  const nav = $('nav');

  if (menuButton && nav) {

    menuButton.addEventListener('click', () => {

      nav.classList.toggle('open');

      menuButton.setAttribute(
        'aria-expanded',
        nav.classList.contains('open')
      );

    });

  }

}


// フッター
const footer = $('footer');

if (footer) {

  footer.innerHTML = `
    <footer class="footer">
      <div class="wrap">

        <p class="logo">${SITE.name}</p>

        <p class="small">
          福岡のお出かけスポット紹介サイト（卒業制作）
        </p>

      </div>
    </footer>
  `;

}


// TOPページ
if ($('category-banners')) {

  // カテゴリー
  $('category-banners').innerHTML =
    CATEGORIES.map(category => `

      <a
        class="banner"
        href="category.html?cat=${category.id}"
      >

        <div class="ph">

          <span class="dummy">
            ${category.name}バナー
          </span>

          <img
            src="images/banners/category-${category.id}.jpg"
            alt="${category.name}"
            onerror="this.remove()"
          >

        </div>

        <p class="cat-label">

          <span class="en">
            ${category.en || ''}
          </span>

          ${category.name}

        </p>

      </a>

    `).join('');


  // おすすめ
  renderCards(
    $('recommend'),
    SPOTS.filter(spot => spot.recommend).slice(0, 3)
  );


  // 特集
  $('features').innerHTML =
    FEATURES.slice(0, 3).map(feature => `

      <a
        class="banner"
        href="feature.html?id=${feature.id}"
      >

        <div class="ph">

          ${bannerPic(
            `images/banners/feature-${feature.id}-pc.jpg`,
            `images/banners/feature-${feature.id}-sp.jpg`,
            `${feature.title}バナー`
          )}

        </div>

      </a>

    `).join('');


  // 新着
  renderCards(
    $('new-spots'),
    SPOTS.slice(-4).reverse()
  );

}


// カテゴリー一覧
if ($('spot-list')) {

  const category =
    CATEGORIES.find(c => c.id === params.get('cat'))
    || CATEGORIES[0];


  document.title =
    `${category.name}｜${SITE.name}`;


  $('cat-title').innerHTML = `
    <span class="en">
      ${category.en || ''}
    </span>
    ${category.name}
  `;


  $('cat-desc').textContent =
    category.desc;


  const categorySpots =
    SPOTS.filter(
      spot => spot.category === category.id
    );


  renderCards(
    $('spot-list'),
    categorySpots
  );


  // 人数フィルター
  document
    .querySelectorAll('#tabs button')
    .forEach(button => {

      button.addEventListener('click', () => {

        document
          .querySelectorAll('#tabs button')
          .forEach(btn =>
            btn.classList.remove('active')
          );


        button.classList.add('active');


        const people =
          button.dataset.people;


        const filtered =
          people === 'all'
            ? categorySpots
            : categorySpots.filter(
                spot =>
                  spot.people.includes(
                    Number(people)
                  )
              );


        renderCards(
          $('spot-list'),
          filtered
        );

      });

    });


  // 他カテゴリー
  $('other-cats').innerHTML =
    CATEGORIES
      .filter(c => c.id !== category.id)
      .map(c => `
        <a href="category.html?cat=${c.id}">
          ${c.name}
        </a>
      `)
      .join('');

}


// スポット詳細
if ($('spot')) {

  const spot =
    SPOTS.find(
      item => item.id === params.get('id')
    )
    || SPOTS[0];


  document.title =
    `${spot.name}｜${SITE.name}`;


  const info = [

    ['料金の目安', spot.price],

    ['営業時間', spot.hours],

    ['アクセス', spot.access]

  ]
    .filter(row => row[1])

    .map(row => `
      <dt>${row[0]}</dt>
      <dd>${row[1]}</dd>
    `)

    .join('');


  const related =
    SPOTS
      .filter(item =>
        item.category === spot.category &&
        item.id !== spot.id
      )
      .slice(0, 3);


  $('spot').innerHTML = `

    <p class="crumb small">

      <a href="index.html">
        ホーム
      </a>

      &gt;

      <a href="category.html?cat=${spot.category}">
        ${catName(spot.category)}
      </a>

      &gt;

      ${spot.name}

    </p>


    <div class="detail-main">
      ${photo(spot.image, spot.name)}
    </div>


    <h1 class="spot-title">
      ${spot.name}
    </h1>


    <p class="small">
      ${catName(spot.category)}
      　
      ${spot.area}
      　
      ${peopleText(spot)}
      ${kidsLabel(spot)}
    </p>


    <p class="lead">
      ${spot.summary}
    </p>


    ${
      spot.points
        ? `
          ${secTitle(
            'Point',
            'おすすめポイント'
          )}

          ${spot.points
            .map(point => `<p>${point}</p>`)
            .join('')}
        `
        : ''
    }


    ${
      spot.gallery &&
      spot.gallery.length

        ? `
          ${secTitle(
            'Photos',
            '写真'
          )}

          <div class="gallery">

            ${spot.gallery
              .map(image =>
                photo(image, spot.name)
              )
              .join('')}

          </div>
        `

        : ''
    }


    ${secTitle(
      'Info',
      '基本情報'
    )}


    <dl class="info">
      ${info}
    </dl>


    ${
      related.length

        ? `
          ${secTitle(
            'Related',
            '関連スポット'
          )}

          <div class="card-grid">

            ${related
              .map(card)
              .join('')}

          </div>
        `

        : ''
    }

  `;

}


// 特集ページ
if ($('feature')) {

  const feature =
    FEATURES.find(
      item => item.id === params.get('id')
    )
    || FEATURES[0];


  document.title =
    `${feature.title}｜${SITE.name}`;


  $('feature-title').textContent =
    feature.title;


  $('feature-intro').textContent =
    feature.intro;


  const featureSpots =
    feature.spots
      .map(id =>
        SPOTS.find(
          spot => spot.id === id
        )
      )
      .filter(Boolean);


  renderCards(
    $('feature-list'),
    featureSpots
  );

}


// オープニング
function initOpening() {

  const opening =
    document.getElementById('opening');

  const root =
    document.documentElement;


  if (!opening) return;


  let alreadyOpened = false;


  try {

    alreadyOpened =
      sessionStorage.getItem('opened') === '1';

  } catch (error) {

    console.log(
      'sessionStorageを使用できません'
    );

  }


  // すでに表示済み
  if (alreadyOpened) {

    opening.remove();

    root.classList.remove(
      'opening-on'
    );

    return;

  }


  // オープニング終了
  const finishOpening = () => {

    if (!opening.isConnected) return;


    opening.remove();

    root.classList.remove(
      'opening-on'
    );


    try {

      sessionStorage.setItem(
        'opened',
        '1'
      );

    } catch (error) {

      console.log(
        'sessionStorageを使用できません'
      );

    }

  };


  // 動きを減らす設定
  if (
    window.matchMedia(
      '(prefers-reduced-motion: reduce)'
    ).matches
  ) {

    finishOpening();

    return;

  }


  // ペイントを落とす
  setTimeout(() => {

    if (opening.isConnected) {
      opening.classList.add('out');
    }

  }, 2200);


  // 必ずTOPへ
  setTimeout(
    finishOpening,
    3400
  );

}


initOpening();